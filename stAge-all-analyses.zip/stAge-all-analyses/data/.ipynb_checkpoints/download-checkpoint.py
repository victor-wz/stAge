#!/usr/bin/env python
"""Download public datasets used by this release's analyses/ scripts.

Every accession below was found as a literal directory/file name somewhere in the
original (private) project tree during the code audit -- see the `source` field on
each entry for exactly where. None of this repo's private/unpublished data is
included or referenced here; this script only ever talks to NCBI GEO via the
`GEOparse` package (see environment.yml).

This list is NOT guaranteed complete or address-confirmed -- accessions were
recovered from directory/file naming conventions during a code audit, not by
cross-checking each one against the paper's own data-availability statement.
Verify every entry against that statement before treating this as authoritative,
and fill in the "MOSTA" entry (a well-known public spatial atlas, but this repo
audit did not surface a specific version/URL to pin -- confirm with the authors
before large downloads).

Usage:
    python data/download.py --list                 # show the registry, download nothing
    python data/download.py --dataset brain3g       # download one entry
    python data/download.py --all                   # download everything (slow, large)
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass, field


@dataclass
class Dataset:
    key: str
    accessions: list[str]  # GEO series (GSExxxxx) and/or sample (GSMxxxxx) IDs
    source: str            # where this accession was found during the audit
    notes: str = ""


REGISTRY: dict[str, Dataset] = {
    "brain3g": Dataset(
        key="brain3g",
        accessions=["GSE212903"],
        source="directory name `GSE212903_brain3g` (stage_res_pred.ipynb, "
               "two_stage_composition_correction.ipynb raw-data paths)",
        notes="Individual samples referenced elsewhere in the codebase: "
              "GSM6560897/GSM6560900 (Young), GSM6560899/GSM6560902 (Old), "
              "GSM6560898/GSM6560901 (Mid-age, excluded from Young/Old analyses "
              "throughout this pipeline) -- per FigureS11.md.",
    ),
    "skmuscle_injury": Dataset(
        key="skmuscle_injury",
        accessions=["GSE266933"],
        source="directory name `GSE266933_skmuscle` (stage_res_pred.ipynb active config)",
    ),
    "ovary_sharif": Dataset(
        key="ovary_sharif",
        accessions=["GSE232309"],
        source="`GSE232309_age.combined.RDS` found directly in scripts/ovary_sharif/; "
               "individual sample files also present: GSM7325156, GSM7325160",
    ),
    "cecilia_microglia": Dataset(
        key="cecilia_microglia",
        accessions=["GSE121654"],
        source="directory `v_pipeline/cecilia_microglia/as_h5ad/GSE121654/`",
    ),
    "convert_to_h5ad_misc": Dataset(
        key="convert_to_h5ad_misc",
        accessions=["GSE208292", "GSM7440144", "GSM8341584", "GSE270383"],
        source="convert_to_h5ad.ipynb per-dataset raw-data subpaths",
        notes="Four separate raw-format conversion targets in one notebook -- "
              "confirm which figure(s), if any, each actually feeds before "
              "assuming all four are needed for a full reproduction.",
    ),
    "mosta": Dataset(
        key="mosta",
        accessions=[],
        source="directory name `MOSTA` / `data/MOSTA` (CLAUDE.md data layout; "
               "MOSTA/Step1-5 scripts)",
        notes="TODO(unconfirmed): likely the public Mouse Organogenesis "
              "Spatiotemporal Transcriptomic Atlas (Chen et al. 2022), but no "
              "specific accession/version/URL was recovered from the audited "
              "code -- fill this in from the paper's data-availability "
              "statement rather than guessing a URL here.",
    ),
}


def _download_geo(accession: str, out_dir: str) -> None:
    import GEOparse

    os.makedirs(out_dir, exist_ok=True)
    print(f"Fetching {accession} -> {out_dir}")
    GEOparse.get_GEO(geo=accession, destdir=out_dir)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", action="store_true", help="print the registry and exit")
    ap.add_argument("--dataset", choices=sorted(REGISTRY), help="download one registry entry")
    ap.add_argument("--all", action="store_true", help="download every entry with a known accession")
    ap.add_argument("--out-dir", default=os.path.join(os.path.dirname(__file__), "raw"),
                     help="destination root (default: data/raw/, gitignored)")
    args = ap.parse_args()

    if args.list or not (args.dataset or args.all):
        for key, ds in REGISTRY.items():
            print(f"{key}:")
            print(f"  accessions: {ds.accessions or '(none recovered -- see notes)'}")
            print(f"  source: {ds.source}")
            if ds.notes:
                print(f"  notes: {ds.notes}")
        if not (args.dataset or args.all):
            return

    targets = [REGISTRY[args.dataset]] if args.dataset else list(REGISTRY.values())
    for ds in targets:
        if not ds.accessions:
            print(f"Skipping {ds.key}: no accession recovered from the code audit -- see notes above.",
                  file=sys.stderr)
            continue
        ds_dir = os.path.join(args.out_dir, ds.key)
        for acc in ds.accessions:
            _download_geo(acc, ds_dir)


if __name__ == "__main__":
    main()
