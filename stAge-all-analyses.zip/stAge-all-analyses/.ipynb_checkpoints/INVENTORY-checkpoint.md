# stAge code-release inventory (Phase 1)

Source tree audited (READ-ONLY, nothing in it was modified): `/Entropy/Projects/spatial_aging/vvicente/scripts/`
(same underlying filesystem as `/home/vvicente/spatial_aging/vvicente/scripts/`, confirmed via matching device:inode).

Scope actually found on disk, beyond what the task brief anticipated: the "main" pipeline lives in `v_pipeline/`,
but there are **six additional, mostly pre-`v_pipeline` dataset-specific pipeline directories**
(`immuno/`, `immuno_psb/`, `MOSTA/`, `MOSTA_psb/`, `univ/`, `integrated_stAge/`) plus two shared top-level R
scripts. These are not documented in `v_pipeline/CLAUDE.md` at all. Two of them (`integrated_stAge/` notebooks
`ORS_validation_stAge.ipynb` and `smoothing_integrated_stAge.ipynb`) turned out to be the **actual code behind
named paper figures** (Fig S3, Fig 1c) — i.e. figures are not all produced from `v_pipeline/`. `d_pipeline/`,
`ovary_sharif/`, `ct_reference/`, `cecilia_microglia/`, and `vvicente/results/` were checked and contain **only
data/output files, no code** (confirmed via recursive search for `.py`/`.R`/`.ipynb`).

Four background inventory passes fed this document (Python core modules; core prediction notebooks; downstream
hotspot/composition notebooks; dataset-specific pipeline directories). All notebooks were read via
`jupyter nbconvert --to script --stdout` (never the raw `.ipynb`, and nothing was written back into the source
tree).

No credentials, API keys, tokens, or PHI/unpublished-dataset markers were found anywhere in this codebase.
All dataset identifiers encountered (GSE/GSM accessions) are public GEO series.

---

## Part A — `v_pipeline/` core Python modules

### `v_pipeline/st_utils.py`
- **What**: Primary/canonical tAge pipeline module — metapixel construction (overlapping KD-tree via `select_neighbors`, non-overlapping Leiden via `non_overlapping_MPs`), `filter_genes`, normalization (`preprocess_counts`/`get_scaled_counts`, `YuGene`/`get_YuGene_counts`), `final_clock_preparation`, `predict_age`, `propagate_into_pixel_level`, and three end-to-end drivers `full_mp_pipeline`, `full_nonoverlap_mp_pipeline`, `nonoverlap_mp_and_filter`+`preprocess_and_predict`.
- **Maps to**: SpatialGroup metaspot clustering; clock prediction pipeline (Figs 2, 3, S4, S5). Core module — feeds essentially every tAge result in the paper.
- **Inputs/outputs**: hard-coded clock paths `/home/vvicente/spatial_aging/tAge_clocks/tms_clocks/EN_Chronoage_Mouse_All_WT_{scaleddiff,yugenediff}.pkl`; `f'/home/vvicente/spatial_aging/{clock_folder}/EN_Chronoage_Mouse_All_WT_{scaleddiff,yugenediff}.pkl'`; relative `"vvicente/scripts/v_pipeline/Mus_musculus.gene_info"` (requires cwd = `/home/vvicente/spatial_aging/`). Outputs: `{save_dir}/{tag}_preds.{parquet,h5ad}`, `{save_dir}/{tag}_{scaled,yugene}_plot.png`.
- **Status**: current — newest mtime in the repo (Aug 4 2026); imported by nearly every `v_pipeline/` notebook.
- **Duplicates**: see `outdated/st_utils.py` and `integrated_stAge/st_utils.py` below.

### `v_pipeline/st_utils_claude.py`
- **What**: A "cleaned-up" rewrite of `st_utils.py` — **not functionally equivalent**: its `non_overlapping_MPs` does per-spot KD-tree neighbor-mean spatial *smoothing* (same n_obs as input, no clustering/aggregation) instead of Leiden-clustered pseudobulk metapixels, despite the identical function/pipeline names.
- **Maps to**: nominally the same functions as `st_utils.py`, but unused — maps to no actual figure.
- **Inputs/outputs**: same clock-path pattern as `st_utils.py`.
- **Status**: **dead**. `grep` across the whole tree finds no `import st_utils_claude` anywhere, only a self-referential code comment inside `st_utils.py`. Because it diverges silently in behavior, it would produce wrong results if ever imported by mistake.
- **Flag**: none.

### `v_pipeline/stage_dstream.py`
- **What**: Downstream analytics utilities — pairwise gene-expression/tAge distance regression + volcano plots, hotspot annotation (quantile-based and Getis-Ord Gi*), DE volcano plots, `gseapy`/Enrichr enrichment, `random_effects_meta`/`self_contained_from_meta` (Stouffer-Z self-contained gene-set testing), Venn-diagram gene-overlap plotting.
- **Maps to**: `annotate_hotspot_gi` → Getis-Ord hotspot annotation (Fig 6a); `random_effects_meta` → inverse-variance meta-signatures (Figs 6c, S7); `self_contained_from_meta` → self-contained GSEA (Figs 6d, S8); `run_enrichment`/`intersect_and_enrich` → pathway enrichment panels.
- **Inputs/outputs**: no hard-coded absolute paths; all I/O via function params or `gseapy` network calls.
- **Status**: current — imported (`from stage_dstream import *`) by `stage_dstream_loop.py`, `dstream_clean.ipynb`, `dstream_loop.ipynb`, `stage_modules_pred.ipynb`, and `outdated/dstream_loop.ipynb`.

### `v_pipeline/stage_dstream_loop.py`
- **What**: Loop-based downstream variant — GSEA-prerank (`gsea_prerank_df`), inter-tissue NES-correlation clustering (`nes_correlation_pipeline`), self-contained ssGSEA testing (`self_contained_gsea_ssgsea`); imports `st_utils`+`stage_dstream` via `import *`. Contains an internal code-quality issue: `_prep_deg_table`/`random_effects_meta`/`mixed_meta_from_deg_tables` are defined **twice, verbatim**, in the same file (lines 494–583 and 662–750).
- **Maps to**: `nes_correlation_pipeline` → inter-tissue pathway-similarity heatmap; `mixed_meta_from_deg_tables`/`random_effects_meta` → cross-tissue meta-analysis (Figs 6c, S7); `self_contained_gsea_ssgsea` → self-contained GSEA (Figs 6d, S8).
- **Status**: current — imported by `two_stage_multi_dataset.ipynb`, `hotspot_senescence_stAge.ipynb`, `dstream_loop.ipynb`, `stage_modules_pred.ipynb`.

### `v_pipeline/stage_big_pred.py`
- **What**: RAM-efficient large-dataset variant — writes per-sample non-overlapping-metapixel AnnData to disk (`integrated_nonoverlap_incremental_filter`), computes a global gene filter across temp files (`load_filter_write`), then predicts from disk (`preprocess_and_predict_from_disk`).
- **Maps to**: disk-based execution path named in CLAUDE.md; no single figure.
- **Inputs/outputs**: hard-coded `/home/vvicente/spatial_aging/tAge_clocks/EN differential models 4.6/EN_Chronoage_Mouse_All_WT_{scaleddiff,yugenediff}.pkl` — note this uses the **original, non-TMS** clock folder, unlike `st_utils.full_mp_pipeline`'s hard-coded TMS clock (an inconsistency worth flagging, not necessarily a bug).
- **Status**: current — imported by `big_stage_pred.ipynb`.
- **Known bug**: `integrated_nonoverlap_incremental_filter` references an undefined variable `ipynb_dir` (line 68) — only works if the calling notebook happens to have that global already set; a latent `NameError` if called standalone. Reported only, not fixed.

### `v_pipeline/stage_pred_gne.py`
- **What**: Undocumented (absent from CLAUDE.md), older/dense-matrix variant of the non-overlapping metapixel pipeline, structurally close to the pre-optimization `outdated/st_utils.py`. Purpose/name ("gne") unclear — no docstring.
- **Maps to**: nominally the same non-overlapping-MP execution path — but unreachable in practice.
- **Status**: **dead, and buggy even if revived**. Zero references anywhere else in the tree. Independently, `full_nonoverlap_mp_pipeline` in this file never assigns its per-file result into the output dict, so it **always returns an empty dict**. Also has a path typo: `ncbi_reference_path="vvicente/scripts/d_pipeline/Mus_musculus.gene_info"` (should be `v_pipeline`; that path doesn't exist).

### `v_pipeline/st_resol.py`
- **What**: Automated Leiden-resolution search (`optimal_resolution_search` / `select_best_resolution` / `normalize_minmax`) — the code behind the paper's Optimal Resolution Search analysis.
- **Maps to**: Optimal resolution search (composite score). **Verified against code**: `score = 0.4·norm(T) + 0.6·norm(Cohen's d)` (default `tstat_weight=0.4`, `cohen_weight=0.6` — so the paper's "a·T + b·Cohen's d" holds with a=0.4, b=0.6, and Cohen's d weighted more than T). `res_range` default `[0.25, 0.5, 1, 1.5, 2, 4, 8, 16]` matches CLAUDE.md exactly. **Discrepancy**: the function's own default `tolerance=0.05` (5%), not 10% — but every actual call site (`integrated_stAge.ipynb`, `stage_res_pred.ipynb`, `stage_res_pred-Copy1.ipynb`, `two_stage_composition_correction.ipynb`, both `integrated_stAge/` copies) explicitly passes `tolerance=0.1` with an inline comment confirming "10%", so the analysis as actually run does match the paper; only the unused default is off. Reported for awareness, not a bug in practice.
- **Status**: current — imported by 6 notebooks in `v_pipeline/`.
- **Duplicates**: near-identical to `integrated_stAge/st_resol.py` (see below) — 3-line diff, both required (different clock-path conventions in their respective sibling `st_utils.py`).

### `v_pipeline/outdated/st_utils.py`
- **What**: Older, pre-optimization snapshot of `st_utils.py`; lives (by design) in a folder named `outdated/`, alongside a whole retired notebook pair (`dstream_clean.ipynb`, `dstream_loop.ipynb`).
- **Status**: superseded (mtime Apr 2025, vs. current's Aug 2026). **Diff vs. current `st_utils.py`**: 630 changed lines — `non_overlapping_MPs` rewritten from dense `.toarray()`+pandas-groupby to sparse indicator-matmul (memory safety on large slices) and no longer returns a pixel-level broadcast inline; `propagate_into_pixel_level` didn't exist in the outdated version — it's new in current, replacing that inline broadcast with a dedicated, memory-safe function; current adds `sklearn.pipeline.Pipeline` compatibility throughout; current fixes the same `d_pipeline`→`v_pipeline` path typo seen live in `stage_pred_gne.py`. Current is unambiguously canonical.

### `integrated_stAge/st_utils.py` (separate directory from `v_pipeline/`)
- **What**: A parallel fork of `st_utils.py`, used only by the `integrated_stAge/` notebook set. Mid-way in sophistication between `outdated/st_utils.py` and current `v_pipeline/st_utils.py`.
- **Status**: current *for that directory's own notebooks* (`integrated_stAge.ipynb`, `smoothing_integrated_stAge.ipynb`, `ORS_validation_stAge.ipynb`), but a **divergent, unmerged duplicate** relative to `v_pipeline/st_utils.py` — mtime Dec 2025. **Diff vs. `v_pipeline/st_utils.py`**: 279 changed lines — still uses the dense `.toarray()`+groupby aggregation and the older, non-memory-optimized `propagate_into_pixel_level` (O(n) substring scan instead of O(1) dict lookup); uses `os.getcwd()`-relative NCBI reference path instead of the hard-coded `v_pipeline` relative path; lacks the `metapixel_maps` caching added in current `nonoverlap_mp_and_filter`.
- **Duplicates**: not merged into `v_pipeline/st_utils.py` — this is a real fork-drift situation the user needs to decide on (see "Duplicates requiring a decision" below).

### `integrated_stAge/st_resol.py`
- **What**: Copy of `st_resol.py`, adapted to `integrated_stAge/st_utils.py`'s non-absolute clock-path convention.
- **Duplicates**: diff vs. `v_pipeline/st_resol.py` is only 3 lines (`clock_dirs` uses full absolute paths here vs. bare relative subfolder names in `v_pipeline`'s version) — a *necessary* divergence matched to each directory's sibling `st_utils.py`, not drift. Both copies are needed as-is if both notebook sets are kept.

---

## Part B — `v_pipeline/` core prediction notebooks

### `big_stage_pred.ipynb`
- **What**: RAM-efficient full-pipeline driver (default dataset: MOSTA whole-mouse embryo atlas) using `stage_big_pred.py`.
- **Maps to**: large-dataset tAge prediction workflow; no single figure identified.
- **I/O**: `rawdata_dir='vvicente/stomics_datasets/notion2/as_h5ad/wholemouse'`; clocks `/home/vvicente/spatial_aging/tAge_clocks/EN differential models 4.6/EN_Chronoage_Mouse_All_WT_{scaleddiff,yugenediff}.pkl`; outputs to `{save_dir}/...` and `{ipynb_dir}/filtered_adatas/saved/pred_{file}.h5ad`.
- **Status**: current, in CLAUDE.md's Key Notebooks table, complete end-to-end.

### `convert_to_h5ad.ipynb`
- **What**: Grab-bag ETL notebook: 10x CellRanger H5, MTX triplets, Stereo-seq/BGI GEM (manual + `stereopy`), legacy "European" ST TSV, Visium `tissue_positions.parquet`→CSV.
- **Maps to**: raw-data ingestion utility, no figure.
- **I/O**: `os.chdir('/home/vvicente/spatial_aging')`; `rawdata_dir = "/Entropy/Projects/spatial_aging/vvicente/scripts/v_pipeline/cecilia_microglia"`; per-dataset GEO-accession subpaths (GSE208292, GSM7440144, GSM8341584, GSE270383 — public); outputs `{output_dir}/{prefix}.h5ad`.
- **Status**: **dead/scratch** — contains an actual Python syntax error (`spatial.iloc[,0]`, line 873), proof it was never run clean top-to-bottom; not in CLAUDE.md's table; heavy copy-paste-per-dataset structure.

### `dstream_clean.ipynb`
- **What**: Main single-run downstream-analysis notebook — spatial/violin plots, pairwise ΔtAge~distance proximity models, Getis-Ord Gi*, gene-proximity mediator models, hotspot DE, neighborhood enrichment, cell-type-proportion comparisons across hotspots.
- **I/O**: `from stage_dstream import *`; outputs `{ipynb_dir}/{upreg,downreg}_prox_genes.pkl`, `{ipynb_dir}/dstream_genes/{upreg,downreg}_DE_genes.pkl`.
- **Status**: current (mtime Oct 2025); ends in an explicit "Tinkering:" exploratory tail (unused `local_smoothing_model`).
- **Duplicates**: canonical vs. `outdated/dstream_clean.ipynb` (below).

### `dstream_loop.ipynb`
- **What**: Cross-tissue "loop" variant — builds `gene_vectors_de`/`per_tissue_tables_de` caches, runs competitive GSEA/metasignature enrichment, cross-tissue NES heatmaps, Venn/UpSet gene-overlap plots. **This is the likely source of the cached DESeq2 hotspot-vs-coldspot tables** that `hotspot_signature_correlation_by_age.ipynb` reads (`intermediate/per_tissue_tables_de_{YOUNG,OLD}_*_Gi>1_DEseq2.pkl.gz`) — i.e. this notebook plausibly contains the actual Fig 6b (pseudobulk DESeq2 hotspot vs coldspot, R) computation, though no batch pass directly confirmed R/DESeq2 call code inside it; **flagged as unconfirmed, see gap list below.**
- **I/O**: `from stage_dstream import *` + `from stage_dstream_loop import *`; `rawdata_dir='data/immunoglobulin'`; `preds_folder='h5ad_other_age_preds'`; writes `intermediate/gene_vectors_de_OLD_Gi>1_DEseq2.pkl.gz`.
- **Status**: current — largest of the dstream family (4870 converted lines); matches `stage_dstream_loop.py` exactly.
- **Duplicates**: canonical vs. `outdated/dstream_loop.ipynb` (below).

### `outdated/dstream_clean.ipynb`
- Earlier draft; imports a since-removed `st_plots` module (not `stage_dstream`); missing hotspot-DE/deconvolution/neighborhood-enrichment sections. Diff vs. current: 4480 changed lines (near-total rewrite). mtime Apr 2025 vs. current's Oct 2025. **Superseded — current version is canonical.**

### `outdated/dstream_loop.ipynb`
- Earlier draft; already imports `stage_dstream` but not yet `stage_dstream_loop` (predates that module); missing mature GSEA/heatmap sections. Diff vs. current: 4351 changed lines. mtime Jul 2025 vs. Oct 2025. **Superseded — current version is canonical.**

### `suppfig_smoothing_comparison.ipynb`
- **What**: Full aggregation-strategy benchmark notebook — panels A–C (spatial maps/violin/dropout), Cohen's d/Mann-Whitney benchmarking, Gi* hotspot-reproducibility+Jaccard, 5-panel figure, Transcriptomic-Leiden/Grid/Anatomical ablation vs. SpatialGroup — matches CLAUDE.md's cell-by-cell description exactly, **plus** one undocumented additional section not in CLAUDE.md: "8 · Multi-tissue Cohen's d — pre-normalization smoothing" (~line 1773 of converted script).
- **Maps to**: Fig 1c (aggregation-strategy benchmark) and the Getis-Ord Gi* hotspot-reproducibility component.
- **I/O**: `RAW_DIR='/home/vvicente/spatial_aging/data/immunoglobulin'`; `CLOCK_PATH` base `.../tAge_clocks/`; `SAVE_DIR='/home/vvicente/spatial_aging/vvicente/results'`; config `LEIDEN_RES=2`, `MP_THRESHOLD=1_000`, `SMOOTHING_KS=[5,10,20]`. **Tissue selector (cell 7) currently set to `Liver`**, not `Hippocampus` as CLAUDE.md's example implies — last-executed state diverges from the `.py` mirror's hardcoded tissue.
- **Status**: current, in CLAUDE.md's table.

### `suppfig_smoothing_comparison.py`
- **What**: Standalone script — **verified** to implement only Panels A–C exactly (sections 1–4), matching CLAUDE.md's "clean standalone version" claim precisely; hardcoded to `Hippocampus`.
- **I/O**: `RAW_DIR`, `CLOCK_PATH` (mouse `EN differential models 4.6/EN_Chronoage_Mouse_All_WT_scaleddiff.pkl`), `SAVE_DIR` same as above.
- **Status**: current — the directly-runnable entry point named in CLAUDE.md's "Running scripts" section. mtime Mar 2026, older than the notebook (Jun 2026) — the notebook kept growing after this script was forked off it.

### `stage_res_pred.ipynb`
- **What**: Very large multi-dataset "workhorse" — for each of 15+ raw ST datasets (ovary, bone, heartbreak, spinalcrush, brain3g/25, thymus, MOSTA embryo, GSE266933_skmuscle [active config], human cortex, maternal_interface, etc.), runs `optimal_resolution_search` then predicts tAge at the optimal resolution; also does "clock contribution mapping," "gene contribution to tAge in interventions," and a maternal/fetal-interface (MFI) distance-analysis section (~line 3758).
- **Maps to**: confirms CLAUDE.md's "Leiden resolution sweep and selection," but functions much more broadly as the primary per-dataset driver feeding most tissue-level figures; the MFI section is a plausible but **unconfirmed-in-detail** source for the maternal-fetal interface figure (Fig 7i-k) — LOWESS/Fisher-z specifics not directly verified in this pass.
- **I/O**: active dataset `rawdata_dir='vvicente/stomics_datasets/notion2/as_h5ad/GSE266933_skmuscle'`; multiple clock paths (mouse TMS, mouse EN 4.6, human "EN differential models 5.4"); `OUT_DIR=Path("/home/vvicente/spatial_aging/vvicente")`; outputs include `{ipynb_dir}/FIGURES/{...}_MEM_{whole_boxplot,tissue_barplot}.pdf` (whole-mouse mixed-effects figure outputs, matching the files seen in `v_pipeline/FIGURES/`).
- **Status**: current, in CLAUDE.md's table (mtime Jul 2026); organized into numbered per-dataset sections, requires manual reconfiguration between datasets (not single-shot batch).
- **Also contains** (per `FigS7.md`'s appendix, already known from inherited context): a documented bug-then-fix in an earlier version of its maternal/fetal-splitting cell (fixed version pasted into `FigS7.md` for reference — verify the live notebook cell matches that fix, not independently re-verified in this pass).

### `stage_res_pred-Copy1.ipynb`
- **What**: A live fork of `stage_res_pred.ipynb`, structurally identical section-for-section, but configured for `maternal_interface` and adding ~150 lines of **new, undocumented** code: a marker-gene-panel fetal/maternal compartment classifier (`FETAL_PANELS`/`MATERNAL_PANELS`, two-pass z-scored `fetal_delta` splitting into `Maternal.k`/`Fetal.k`).
- **Status**: **the single newest file in the entire repository** (mtime Aug 4 2026, 20:12 — newer than `stage_res_pred.ipynb` itself and even newer than `CLAUDE.md`). Not in CLAUDE.md's table; the "-Copy1" name is Jupyter's auto-duplicate convention. Diff vs. `stage_res_pred.ipynb`: 936 changed lines — **not a passive duplicate**; it currently holds functionality (the fetal/maternal classifier) that exists nowhere else in the codebase.
- **Recommendation flagged by the sub-agent**: this maternal/fetal classifier logic should be reconciled/merged into the canonical pipeline before release, not discarded as a stray "-Copy1" file.

### `integrated_stAge.ipynb` (in `v_pipeline/`, distinct from the `integrated_stAge/` directory)
- **What**: A thin wrapper — defines one function `stAge(rawdata_dir, control_file_pattern, ORS, alt_res, clocks_dir, spatial_plot, box_plot, group_patterns, save_at_spot, save_at_metaspot, save_dir)` composing `optimal_resolution_search` + `full_nonoverlap_mp_pipeline` + plotting, plus one example call. Only 203 converted lines total.
- **Status**: CLAUDE.md's description ("Main per-tissue tAge prediction workflow") **overstates this file** — the heavier analytical work actually lives in `stage_res_pred.ipynb`. **Broken as written**: the function body references `ipynb_dir`, `tag`, `save_folder` that are never defined in the notebook — running it as-is raises `NameError`. The example call's `clocks_dir='/home/vvicente/spatial_aging/EN differential models 4.6'` is also missing the `tAge_clocks/` path segment used everywhere else — a likely broken/stale path.

### `stage_modules_pred.ipynb`
- **What**: Module-specific ("compartment"/pathway) elastic-net clock driver — loads multi-dataset tissue h5ads (brain3g, brain25, human WM/GM cortex, etc.), iterates every `*_scaleddiff.pkl` module clock, predicts tAge per module, builds tissue×module-clock Δ heatmaps with significance annotation, spatial plots of individual module clocks.
- **Maps to**: Module-specific clocks (Figs 6e, 7d, 7h, S9, S10) — header literally says "stAge pipeline applying module clocks."
- **I/O**: `clock_folder='tAge_clocks/EN differential models 4.6'` (commented alt `'tAge_clocks/Module clocks 5.4 multispecies'` for human); writes `{name}_{suffix}.pkl.gz` under `intermediate/` via a `save_to_pkl` helper.
- **Status**: current but **not listed in CLAUDE.md's Key Notebooks table** despite size (804KB raw) and clear figure relevance — likely a documentation gap, not dead code.

---

## Part C — `v_pipeline/` downstream hotspot/composition notebooks + R

### `celltype_hotspot_tAge.ipynb`
- **What**: Multi-section notebook: (1) spot-level Getis-Ord Gi* hotspot/coldspot classification (k=8, 999 perms, BH-FDR<0.05, |z|>1); (2–4) cell-type × hotspot/coldspot pseudobulk construction + clock re-run + stats; (5) "Compositional partitioning" — an Oaxaca-style decomposition; (6) "Regression-based variance partitioning" — an OLS R² approach; plus a separate "Region Analysis" section (marker-gene brain-region annotation, Wang-et-al.-style panel, Leiden res=0.8, 7 canonical regions) for Brain 2g/3g.
- **Maps to**: Getis-Ord Gi* hotspot calling (Fig 6a — though see gap note below on which notebook is truly canonical for this); marker-gene brain region annotation; upstream/companion to composition-independence (Fig S12, via the Section 5 precursor). **No DESeq2 code and no cell-type-abundance analysis found anywhere in this notebook** — Fig 6b and Fig 6f are **not** produced here, contrary to what their section titles might suggest.
- **I/O**: `ct_reference/brain_reannotated/{brain2g_,brain3g_,brain25_}<fname>` (`Cell.type_SingleR`); clock `/home/vvicente/spatial_aging/tAge_clocks/EN differential models 4.6/EN_Chronoage_All_All_WT_scaleddiff.pkl`. **Outputs include two very large caches**: `vvicente/results/region_annotated_Brain_2g.h5ad` (11.6 GB) and `region_annotated_Brain_3g.h5ad` (4.86 GB) — confirms the OOM/memory-pressure narrative already documented in `FigureS11.md`.
- **Status**: current for Sections 1–4 and Region Analysis; Section 5 is **superseded and buggy** (see Known bugs); Section 6 looks like an abandoned alternative method (nothing downstream references its output). The Region Analysis portion contains **4 near-duplicate full re-executions of the same figure-generation code** — iterative-editing residue; only the last iteration is presumably final.
- **Known bug (Section 5, confirmed in code)**: `mean_c_overall = tage_pooled[in_c].mean()` is computed across **all** spots of a cell type, including "normal" spots outside the hotspot/coldspot comparison — breaks the Oaxaca-Blinder identity `delta_obs = delta_comp + delta_within`. Per `FigureS11.md`, this produced reconstruction residuals of 5–20% of `delta_obs` (one sample summed to ~118%). **Fixed, corrected version lives in `spatial_tage_beyond_composition.ipynb` Panel B** — do not treat the two as equivalent if either is cited. Not fixed here, reported only.

### `hotspot_senescence_stAge.ipynb`
- **What**: tAge + SASP/senescence-gene-score analysis across **three unrelated injury/disease datasets**: spinal cord crush (GSE212903-adjacent), myocardial infarction ("heartbreak"), bone fracture — including Gi* hotspot-vs-senescence-score co-localization for spinal cord crush.
- **Maps to**: closest nominal match is SenMayo senescence (Fig 4d), but the actual content (custom ~35-gene SASP-style score, three injury-model datasets, none of which is the whole-mouse natural-aging cohort) doesn't clearly match that or any other figure in the paper's list. **Flagged as an open question** — may be exploratory/unpublished work, or the true source of a figure not fully captured in the given figure taxonomy.
- **I/O**: `RAW_DIR='/home/vvicente/spatial_aging/vvicente/stomics_datasets/notion2/as_h5ad/{spinalcrush,heartbreak,bone}'`; outputs `vvicente/results/{spinalcrush,heartbreak,bone}_SASP_stAge.{pdf,png}`.
- **Status**: mixed — core analysis logic looks functional, but the top import cell currently reads `from stage_dstream_loop.py import *` and `from st_utils.py import *` (literal `.py` in the module path — both would raise `ModuleNotFoundError` if re-executed today), while the cached cell *output* says "Imports OK" — i.e. the saved output is **stale relative to current cell source**, consistent with concurrent hand-editing in a live Jupyter session (per prior session's noted pattern for this repo).
- **Known bug**: broken import lines described above. Reported only, not fixed.

### `hotspot_signature_correlation_by_age.ipynb`
- **What**: Reviewer-response notebook — pairwise cross-tissue Spearman correlation of the DESeq2 hotspot-vs-coldspot log2FC signature (9 tissues, 36 pairs), separately Young/Old, tested via paired Wilcoxon (primary) + paired t-test (secondary).
- **Maps to**: cross-tissue hotspot signature convergence — Fig S6c (documented internally as Panel C of "Figure S7" in `FigS7.md`; **flagging this internal-vs-final numbering mismatch explicitly, not resolving it** — see numbering-discrepancy note below).
- **I/O**: reads cached `intermediate/per_tissue_tables_de_{YOUNG,OLD}_{brains,other}_Gi>1_DEseq2.pkl.gz` (built upstream, likely by `dstream_loop.ipynb` — not itself); writes `vvicente/results/hotspot_signature_correlation_by_age_{pairs.csv,fig.{pdf,png}}`.
- **Status**: current, clean, single-purpose, recently executed (Aug 2026).

### `spatial_tage_beyond_composition.ipynb`
- **What**: Four-panel composition-independence analysis: Panel A — OLS residualization (composition + sample identity) then re-run clock, compared across Gi* hotspot/coldspot, 7 datasets; Panel B — exact symmetric (Reimers/Cotton) Oaxaca-Blinder decomposition, verified in code to reconstruct `delta_obs` exactly (residuals ~1e-7); Panel C — Brain-25-only NEURON_Lin tAge across 7 marker-gene-annotated regions; Panel D — Brain-25-only NEURON_Lin/OLG_Lin tAge across Gi* hotspot/normal/coldspot.
- **Maps to**: documented as "Figure S11" in the co-located `FigureS11.md`, but per separate guidance in this task this maps to **Fig S12** in the paper's actual figure list ("Composition-independence: OLS residualization, Oaxaca-Blinder decomposition, per-cell-type/region pseudobulks") — **the S11-vs-S12 numbering discrepancy is flagged explicitly here and left for the user to resolve, not silently picked either way.**
- **I/O**: `h5ad_other_age_preds/pred_tms_{brain2g,brain3g,brain25}_*.h5ad`, `..._{Hippocampus,Liver,Spinalcord,Intestine}_*_processed.h5ad`; outputs `vvicente/results/metapixel_composition_{7 datasets}.h5ad`, `spatial_tage_residual_hotcold_multidataset.csv`, `spatial_tage_oaxaca_blinder_{persample,summary}.csv`, `spatial_tage_beyond_composition.{pdf,png}`.
- **Status**: current — most recently edited and most thoroughly documented of the composition-confounding lineage; confirmed to use sparse cluster-indicator matmul (not `.toarray()`) for Brain 25's region annotation, consistent with the documented OOM-avoidance rewrite.
- **Duplicates/lineage**: explicitly replaces/corrects `celltype_hotspot_tAge.ipynb` Section 5; is the mature endpoint of a lineage that also includes `two_stage_composition_correction.ipynb` (Mar 16, single dataset) → `two_stage_multi_dataset.ipynb` (Mar 27, 5 datasets) → this notebook (Jul 22, 7 datasets, most rigorous statistics).

### `spatial_tage_variance_by_age.ipynb`
- **What**: Reviewer-response notebook — within-animal spatial tAge variance vs. age across 8 tissues, two-sided Brown-Forsythe (median-centered Levene) test per tissue, effect size = log2(variance ratio Old/Young) with 95% CI from a cluster bootstrap (resample **animals**, not metapixels, 10,000 iterations), plus a cross-tissue Wilcoxon signed-rank test on the 8 per-tissue log2 ratios.
- **Maps to**: spatial tAge variance across age — Fig S6a,b (documented as Panels A/B of internal "Figure S7" — same numbering caveat as above, flagged not resolved).
- **I/O**: `h5ad_other_age_preds/LR_pred_tms_*.h5ad` (LR-clock only; `_reg_` variants and Brain-25 repeat-imaging rounds excluded; non-Young/Old cohorts excluded); outputs `vvicente/results/tage_variance_by_age_{persample,metapixel,tissue_stats}.csv`, `..._fig{1,2}.{pdf,png}`.
- **Status**: current, clean, recently executed (Aug 2026); no bugs found.

### `two_stage_composition_correction.ipynb`
- **What**: Earliest prototype of "regress out composition, re-run clock, compare variance" — single dataset (Hippocampus only), metapixel-centroid-level (not spot-level) Gi* with `z_thresh=0.5`.
- **Status**: superseded — the oldest file in this batch (Mar 16 2026, 45MB raw, the largest file in the whole repo); methodologically weaker than later versions (plain `LinearRegression` residualization with no sample-identity term; underpowered centroid-level Gi*, per `FigureS11.md`'s own note that this approach "left too few significant hotspots/coldspots"). **Some outputs are orphaned outside `vvicente/results/`** — `composition_{variance_explained_bar,scatter_orig_vs_resid,boxplot_hot_cold}.pdf` save with no directory prefix and land at the repo root `/home/vvicente/spatial_aging/`.
- **Duplicates/lineage**: direct ancestor of `two_stage_multi_dataset.ipynb` and `spatial_tage_beyond_composition.ipynb` (see above).

### `two_stage_multi_dataset.ipynb`
- **What**: Middle-generation version — 5 datasets (Hippocampus, Ovary, Liver, Spinal cord, Intestine; Brain 2g/3g/25 present in config but commented out), ad-hoc `sc.tl.score_genes` marker-based cell typing.
- **Status**: superseded/exploratory-only — its only `fig.savefig(...)` call is currently commented out, yet `vvicente/results/composition_confounding_multi_dataset.{pdf,png}` **exists on disk** from an earlier execution — a source/output mismatch (re-running today would not regenerate that file). Never persists CSVs (only in-memory `display()`).
- **Duplicates/lineage**: descendant of `two_stage_composition_correction.ipynb`, precursor to `spatial_tage_beyond_composition.ipynb` Panels A/B.

### `MixedEffectsModel.R`
- **What**: R script using `metafor::rma.uni` meta-regression (per-file yi/vi, moderator = infection timepoint) on **lung-infection** tAge predictions (`lung_infection_df_preds.csv`, columns include `condition ∈ {Young, Aged}`, `time` = days post-infection).
- **Maps to**: plausibly the **lung** half of lung/AD mixed-effects (Fig 5d) — but **no AD-specific code or data reference was found in this script**, so the AD half of Fig 5d is unaccounted for (see gap list). This script is **not** the source of the whole-mouse LPS mixed-effects figure (Fig 4e-g) — the input data has no CTRL/LPS grouping at all; that figure's current code is instead the sample-level-aggregation Python approach documented as a paste-in snippet in `A.md` (see gap note on Fig 4e-g below).
- **Known bug (minor)**: `data <- read.csv("lung_infection_df_preds.csv")`'s result is immediately discarded and shadowed by `data <- lung_infection_df_preds` (an object presumed already in the R environment) — the CSV read is functionally dead code. Reported only.
- **Status**: plausibly current for the lung-infection component, but unverifiable end-to-end (writes no output files at all — all plots are interactive/unsaved).

---

## Part D — dataset-specific pipeline directories (pre-`v_pipeline`, mostly undocumented in CLAUDE.md)

These directories implement the same conceptual stages (metapixel grouping → R filter/preprocess → tAge prediction → undo-metapixel/analysis) per-dataset, predating or running alongside `v_pipeline/`. Several are still needed to reproduce specific dataset predictions consumed downstream (e.g. the immunoglobulin-dataset predictions that `spatial_tage_beyond_composition.ipynb` and `suppfig_smoothing_comparison.ipynb` read from `h5ad_other_age_preds/`).

### `immuno/` (immunoglobulin dataset: Liver, Spinalcord, Intestine, Hippocampus, etc.)
| File | Stage | Status |
|---|---|---|
| `Copy_Step1_metapixel_loop_grouping.ipynb` | metapixel grouping | **Dead** — byte-identical to `MOSTA/Step1_metapixel_loop_grouping.ipynb`, never repointed from MOSTA paths to immuno paths despite living in `immuno/` |
| `iStep1_metapixel_loop_grouping-Copy1.ipynb` | metapixel grouping | Current — actual immuno Step1, feeds the two R scripts below and Step4 |
| `iStep4_apply_tAge.ipynb` | tAge prediction | Current |
| `iStep5_undo_mp_and_analysis_chunks.ipynb` | undo-metapixel + analysis | Current, final step of this pipeline |
| `iSteps2&3_mp_filter_and_FUNpreprocessing_for_clock_3.0_by_chunks.R` | R filter+preprocess | Current — main multi-tissue driver (`Testis`, `Intestine`, `Spleen`) |
| `iiSteps2&3_mp_filter_and_FUNpreprocessing_for_clock_3.0_by_chunks.R` | R filter+preprocess | Current/WIP — single-tissue (`Heart`) patch, 10 days newer, not a pure duplicate of the single-i version (adds `grouping` var, parquet I/O, "still gotta do Heart 'fixed' and 'progressive'" comment) |

No single paper figure identified for this directory as a whole — it's the data-generation pipeline for the immunoglobulin dataset consumed by several `v_pipeline/` downstream notebooks.

### `immuno_psb/` ("psb" = pseudobulk variant of the immunoglobulin pipeline)
| File | Stage | Status |
|---|---|---|
| `step1a_full_pseudobulker.ipynb` | pseudobulk | Current |
| `step2&3_full_psb_filter_and_FUNpreprocess_.R` | R filter+preprocess | Current (tissue-specific, `Lymph`) |
| `step4_psb_tAge.ipynb` | tAge prediction (pseudobulk) | Current — EN clock, single tissue (`Heart`), newer of the pair |
| `step4_loop_psb_tAge.ipynb` | tAge prediction (pseudobulk) | Current — **not a duplicate of step4_psb_tAge**: loops all 9 tissues × Mouse/Rodents with **BR (Bayesian Regression)** clocks, vs. the other's single-tissue **EN**-only run |
| `s4_psb_modules.ipynb` | module clock | **Maps to Figs 6e, 7d, 7h, S9, S10.** Current/canonical (cleaned version, newest mtime) |
| `old/s4_psb_modules.ipynb` | module clock | Superseded draft of the above (extra commented scratch cells) — safe to exclude from release or keep as historical reference only |
| `module_clocks.py` | module clock (shared helper) | Current — imported by both `s4_psb_modules.ipynb` versions; conceptually duplicates `predict_age`/`prepare_prediction_results` in `v_pipeline/st_utils.py` |
| `psb_utils.py` | — | **Dead — confirmed 0 bytes, zero references anywhere in the repo.** Safe to omit. |

### `MOSTA/` and `MOSTA_psb/` (MOSTA developmental spatial atlas)
| File | Stage | Status |
|---|---|---|
| `Step1_metapixel_loop_grouping.ipynb` | metapixel grouping | Current/canonical — the `immuno/Copy_Step1...` file is a stray duplicate of *this* file, not the other way around |
| `Steps2&3_mp_filter_and_FUNpreprocessing_for_clock_3.0_by_chunks.R` | R filter+preprocess | Current for MOSTA, but writes to `/home/vvicente/results/spatial_preprocessed/...` — a **pre-reorg path outside `spatial_aging/`**, needs a path fix before release |
| `Copy_iSteps2&3_mp_filter_and_FUNpreprocessing_for_clock_3.0_by_chunks.R` | R filter+preprocess | **Misfiled** — despite living in `MOSTA/`, this is a hand-edited **immunoglobulin/Hippocampus**-specific prototype (`control_group='_Y_'`, writes to `preprocessed_immuno/`), with a leftover unmodified MOSTA-style block further down (hybrid/inconsistent file). Likely an abandoned early prototype, superseded by the proper `immuno/iSteps2&3...R` |
| `Step4_all_tAge_by_chunks.ipynb` | tAge prediction | Current for MOSTA, same pre-reorg absolute-path staleness (`/home/vvicente/results/...`, `/home/vvicente/models/...`) |
| `Step5_undo_mp_and_analysis_chunks.ipynb` | undo-metapixel + analysis | Current for MOSTA, same path staleness |
| `MOSTA_psb/step1_organ_pseudobulker.ipynb` | pseudobulk | Current/more mature — per-organ filtering (`Brain`/`Liver`/`Heart`), chunked output for cluster jobs |
| `MOSTA_psb/step1_full_pseudobulker.ipynb` | pseudobulk | Likely superseded prototype — no tissue filter, single non-namespaced legacy output path |
| `MOSTA_psb/step2_pre_TACO.R` | R pre-processing (feeds an undocumented external "TACO" step) | Status unclear — "TACO" is not documented anywhere else in this codebase; **flag for confirmation with the author** |

No single paper figure identified for MOSTA as a whole; several files here need their hard-coded pre-reorg paths fixed (`/home/vvicente/results/...`, `/home/vvicente/stomics_datasets/...` rather than the `spatial_aging/`-namespaced convention used everywhere else) before they can run in a fresh checkout.

### `univ/`
- `uStep1_metapixel_loop_grouping.ipynb` — a generalized/parameterized ("universal") rewrite of the immuno Step1 notebook, extracting `create_pixel_grid()`/`progressive_pixel_grouping()` into reusable functions with a config block for dataset-specific layer names. Appears to be a stepping-stone toward what later became `v_pipeline/st_utils.py`'s `select_neighbors`. **Open question for the author**: whether this script (vs. `immuno/iStep1_metapixel_loop_grouping-Copy1.ipynb`) is the one that actually produced any currently-used immuno metapixel output.

### `integrated_stAge/` (separate directory from `v_pipeline/`)
| File | Maps to | Status |
|---|---|---|
| `integrated_stAge.ipynb` | general driver, no single figure | Current — imports the **local** `st_utils.py`/`st_resol.py` in this same directory, not `v_pipeline`'s |
| `ORS_validation_stAge.ipynb` | **ORS robustness: leave-one-sample-out + weight-grid sensitivity — Fig S3** | Current, actively produces `ORS_validation_figure.{pdf,png}` |
| `smoothing_integrated_stAge.ipynb` | **Aggregation-strategy/smoothing benchmark — Fig 1c** | Current — a distinct notebook from (not a file-duplicate of) `v_pipeline/suppfig_smoothing_comparison.ipynb`, which is also Fig-1c-related |

### Top-level shared R scripts
- **`rds_to_h5ad.R`** — Seurat RDS → h5ad conversion utility (`SeuratDisk`/`zellkonverter`-style). Recent mtime (Nov 2025), most of the body is commented-out example code for an "alzheimer_" dataset — **possible partial evidence toward the human AD analysis (Fig 7e)**, but not itself the analysis code; flagged in the gap list below.
- **`reference_cell_annot.R`** — SingleR-based reference cell-type annotation (`library(SingleR)`), processes `data/immunoglobulin` against reference folders. **Maps to SingleR deconvolution (Fig S11) / feeds cell-type abundance (Fig 6f)**, though the abundance *statistics/figure* code itself was not located (see gap list). References `ipynb_dir="vvicente/scripts/old_pipeline"` — **a directory that does not exist anywhere in the current tree; worth confirming with the author whether this path is stale or the directory was renamed/removed.**

---

## Analyses in the paper with NO code found

These items from the provided analysis list were **not** located in any of the ~60 files audited across all directories. Either the code lives somewhere not yet discovered (e.g. a notebook this pass missed, a private/local branch, or work done directly in a REPL and never saved), or it needs to be located by the author.

1. **Human WM/GM annotation (GMM + label smoothing).** `stage_modules_pred.ipynb` loads human white-matter/grey-matter cortex *data*, but no Gaussian-mixture-model + label-smoothing annotation code was found anywhere.
2. **Pseudobulk DESeq2 hotspot vs coldspot (Fig 6b, R).** No R/DESeq2 call code was directly located. Best guess (unconfirmed): embedded somewhere in `dstream_loop.ipynb`, since `hotspot_signature_correlation_by_age.ipynb` reads a cache literally named `..._DEseq2.pkl.gz` that must have been produced by something upstream — but no batch pass found the actual DESeq2/rpy2 call site.
3. **Cell-type abundance (Fig 6f).** `celltype_hotspot_tAge.ipynb` was the most likely candidate and was explicitly checked — confirmed absent. `reference_cell_annot.R` produces the SingleR cell-type calls this would need as an input, but the abundance statistics/figure code itself wasn't found.
4. **Whole-mouse LPS mixed-effects models (Fig 4e-g).** Only a paste-in code **snippet** exists (`v_pipeline/A.md`, "CTRL vs LPS box plot" and "standardized effect size" cells) — no full notebook was found that actually loads the whole-mouse LPS dataset, runs this snippet, and saves a figure. `MixedEffectsModel.R` was checked and is unrelated (lung-infection data, no CTRL/LPS groups). The `{...}_MEM_whole_boxplot.pdf`/`_MEM_tissue_barplot.pdf` outputs referenced by `stage_res_pred.ipynb` may be the actual production path for this figure — not independently confirmed in this pass.
5. **Lung/AD mixed-effects (Fig 5d) — AD half.** `MixedEffectsModel.R` covers only the lung-infection half; no AD-specific mixed-effects code was found anywhere. `rds_to_h5ad.R` has commented-out example code referencing an "alzheimer_" dataset conversion, which may be an early step toward this, but not the analysis itself.
6. **Human AD residual-age OLS (Fig 7e).** Not found in any of the four batches.
7. **Breast cancer tumor vs non-tumor (Fig 7f-h).** Not found in any of the four batches.
8. **Maternal-fetal interface distance gradient specifics (LOWESS, Fisher-z; Fig 7i-k).** The compartment-splitting classifier was found (`stage_res_pred-Copy1.ipynb`, plus the corrected-cell writeup in `FigS7.md`'s appendix) and `stage_res_pred.ipynb` has an "MFI distance-analysis section," but the specific LOWESS/Fisher-z statistical treatment described in the paper was not directly confirmed against that code in this pass.

## Code with no corresponding paper analysis (or unclear/exploratory)

- `stage_pred_gne.py` — dead, unreachable, and broken even if revived.
- `st_utils_claude.py` — dead, and would silently diverge in behavior if ever imported.
- `convert_to_h5ad.ipynb` — pure ETL utility with a live syntax error; not analysis code.
- `immuno/Copy_Step1_metapixel_loop_grouping.ipynb` — dead stray duplicate.
- `immuno_psb/psb_utils.py` — dead, empty file.
- `immuno_psb/old/s4_psb_modules.ipynb` — superseded draft.
- `outdated/dstream_clean.ipynb`, `outdated/dstream_loop.ipynb`, `outdated/st_utils.py` — all superseded by design (directory name).
- `MOSTA/Copy_iSteps2&3...R` — misfiled immuno prototype, not really MOSTA code.
- `MOSTA_psb/step1_full_pseudobulker.ipynb` — likely-superseded prototype of `step1_organ_pseudobulker.ipynb`.
- `MOSTA_psb/step2_pre_TACO.R` — feeds an undocumented external "TACO" step; purpose unconfirmed.
- `hotspot_senescence_stAge.ipynb` — functional but its SASP/injury-model analysis (spinal crush, MI, bone fracture) doesn't clearly correspond to any item in the provided figure list; also currently has broken import statements.
- `celltype_hotspot_tAge.ipynb` Section 6 ("Regression-based variance partitioning") — an apparently-abandoned alternative to the Oaxaca-Blinder approach; nothing downstream references its output.
- `stage_dstream.py`'s pairwise gene-proximity distance model / volcano-plot code — infrastructure with no explicit match in the given figure list (may feed a figure not enumerated in the brief).
- `integrated_stAge.ipynb` (v_pipeline root) — broken as written (undefined names), and its stated purpose is better served by `stage_res_pred.ipynb`.

---

## Duplicate/near-duplicate pairs requiring a canonical-version decision from you

Per your instructions, these are flagged rather than resolved — please tell us which is canonical where it isn't obvious:

1. **`v_pipeline/st_utils.py` vs. `integrated_stAge/st_utils.py`** — genuine, unmerged fork drift (279-line diff). `v_pipeline`'s version is more memory-optimized and `sklearn.Pipeline`-aware; `integrated_stAge`'s version is what actually produces Fig S3 and (partly) Fig 1c today. **These are not simple duplicates — both are load-bearing for different notebooks.** Decide: keep both as-is (documented as intentionally separate), or merge `integrated_stAge/`'s notebooks onto the `v_pipeline` module.
2. **`immuno_psb/step4_psb_tAge.ipynb` vs. `step4_loop_psb_tAge.ipynb`** — different regression type (EN vs. BR) and scope (1 tissue vs. 9×2) — likely both still needed; confirm which (if either) is stale.
3. **`stage_res_pred.ipynb` vs. `stage_res_pred-Copy1.ipynb`** — Copy1 is the newest file in the repo and contains unique, undocumented maternal/fetal-interface classifier code. Needs to be reconciled into the main pipeline, not treated as disposable.
4. **`celltype_hotspot_tAge.ipynb` Section 5 vs. `spatial_tage_beyond_composition.ipynb` Panel B** — not really ambiguous (Panel B is explicitly documented as the fix), but flagging since Section 5's buggy output may already be cited/used in a draft figure or table elsewhere — worth a text search of the manuscript before assuming it's unused.
5. **Fig S11 vs. Fig S12 numbering** — `FigureS11.md` documents `spatial_tage_beyond_composition.ipynb` as "Figure S11," but this task's own analysis list maps that content to "Fig S12." Similarly `FigS7.md` documents `spatial_tage_variance_by_age.ipynb`/`hotspot_signature_correlation_by_age.ipynb` as "Figure S7," mapped elsewhere to "Fig S6a-c." These `.md` files may simply be using draft/working figure numbers that haven't been updated to match the final manuscript — please confirm the current correct numbering before we label the release package's analysis scripts.
6. **Fig 6a canonical source** — Getis-Ord Gi* hotspot calling appears (with consistent parameters: k=8, 999 perms, BH-FDR<0.05, |z|>1) in at least four places: `celltype_hotspot_tAge.ipynb`, `spatial_tage_variance_by_age.ipynb`, `spatial_tage_beyond_composition.ipynb`, and `suppfig_smoothing_comparison.ipynb` (cell 24). All are legitimate uses in their own context, but please confirm which one is the actual source of the published Fig 6a panel.

---

## Task status

All four inventory passes complete. Ready for your review before Phase 2 (proposed `stAge-release/` layout).

1. use `v_pipeline/st_utils.py`
2. use both
3. yes that one was created because the stage_res_pred.ipynb was not being able to get saved. however, maternal interface will be annotated by cell type so that code in the "Copy" nb is not relevant
4. ok
5. yes some supplementary figure numbers have been moved. the propmt's provided names are the good ones
6. yes k=8, 999 perms, BH-FDR<0.05, |z|>1
